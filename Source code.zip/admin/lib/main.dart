import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'backend.dart';

const Color bg = Color(0xFF040A1C);
const Color card = Color(0xFF0A1530);
const Color border = Color(0xFF1C4C99);
const Color accent = Color(0xFF2F8CFF);
const Color accent2 = Color(0xFF33B5FF);
const Color sub = Color(0xFF8FA3C4);

late SharedPreferences prefs;

final ValueNotifier<int> dbState = ValueNotifier<int>(0);
final ValueNotifier<int> dbEpoch = ValueNotifier<int>(0);

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  prefs = await SharedPreferences.getInstance();
  dbState.value = prefs.getInt('sb_state') ?? 0;
  runApp(const AdminApp());
}

class AdminApp extends StatelessWidget {
  const AdminApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'NEXORA Admin',
      themeMode: ThemeMode.dark,
      darkTheme: ThemeData(
        brightness: Brightness.dark,
        useMaterial3: true,
        fontFamily: 'Vazirmatn',
        scaffoldBackgroundColor: bg,
        colorScheme: ColorScheme.fromSeed(seedColor: accent, brightness: Brightness.dark),
      ),
      locale: const Locale('fa'),
      supportedLocales: const [Locale('fa'), Locale('en')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      home: const Gate(),
    );
  }
}

class Gate extends StatelessWidget {
  const Gate({super.key});

  Client _make() {
    final b = (prefs.getString('sb_url') ?? '').trim();
    return Client(b.isEmpty ? kSbUrl : b, (prefs.getString('sb_key') ?? '').trim());
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<int>(
      valueListenable: dbEpoch,
      builder: (context, _, __) => Dashboard(client: _make()),
    );
  }
}

String fmtBytes(num b) {
  if (b < 1024) return '${b.toInt()} B';
  if (b < 1024 * 1024) return '${(b / 1024).toStringAsFixed(1)} KB';
  if (b < 1024 * 1024 * 1024) return '${(b / 1024 / 1024).toStringAsFixed(1)} MB';
  return '${(b / 1024 / 1024 / 1024).toStringAsFixed(2)} GB';
}

String fmtDur(num s) {
  final h = s ~/ 3600;
  final m = (s % 3600) ~/ 60;
  return '$h ساعت $m دقیقه';
}

String ago(int t) {
  final d = DateTime.now().millisecondsSinceEpoch - t;
  if (d < 60000) return 'همین الان';
  if (d < 3600000) return '${d ~/ 60000} دقیقه پیش';
  if (d < 86400000) return '${d ~/ 3600000} ساعت پیش';
  return '${d ~/ 86400000} روز پیش';
}

String flagOf(String code) {
  if (code.length != 2) return '🌐';
  final a = code.toUpperCase().codeUnits;
  return String.fromCharCodes([0x1F1E6 + a[0] - 65, 0x1F1E6 + a[1] - 65]);
}

String _shortId(String id) => id.length > 10 ? id.substring(0, 10) : id;

class Dashboard extends StatefulWidget {
  final Client client;
  const Dashboard({super.key, required this.client});

  @override
  State<Dashboard> createState() => _DashboardState();
}

class _DashboardState extends State<Dashboard> {
  int _tab = 0;
  Map<String, dynamic> _stats = {};
  List<dynamic> _users = [];
  List<dynamic> _configs = [];
  String _err = '';
  Timer? _timer;
  Timer? _liveTimer;
  int _gen = 0;
  int _applied = 0;
  bool _refreshing = false;
  bool _seedTried = false;
  String _seedErr = '';
  bool _snapBusy = false;
  bool _liveBusy = false;
  Map<String, int> _live = {};
  final Set<String> _locTried = {};

  bool get _dbOk => widget.client.ready && dbState.value == 1;

  @override
  void initState() {
    super.initState();
    if (!_dbOk) _tab = 3;
    dbState.addListener(_onDb);
    _load();
    _timer = Timer.periodic(const Duration(seconds: 10), (_) => _load());
    _liveTimer = Timer.periodic(const Duration(seconds: 3), (_) => _liveTick());
    _liveTick();
  }

  void _onDb() {
    if (!mounted) return;
    setState(() {
      if (_dbOk && _tab == 3 && _stats.isEmpty) _tab = 0;
    });
    _load();
  }

  @override
  void didUpdateWidget(covariant Dashboard old) {
    super.didUpdateWidget(old);
    _load();
  }

  @override
  void dispose() {
    dbState.removeListener(_onDb);
    _timer?.cancel();
    _liveTimer?.cancel();
    super.dispose();
  }

  Widget _needDb() => Center(
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            const Icon(Icons.cloud_off_rounded, size: 56, color: sub),
            const SizedBox(height: 14),
            const Text('اول دیتابیس را وصل کن', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
            const SizedBox(height: 8),
            const Text('آمار، کاربران و کانفیگ‌ها بعد از وصل شدن به Supabase روشن می‌شوند.', textAlign: TextAlign.center, style: TextStyle(color: sub, height: 1.7)),
            const SizedBox(height: 16),
            FilledButton.icon(onPressed: () => setState(() => _tab = 3), icon: const Icon(Icons.cloud_queue_rounded), label: const Text('رفتن به تب دیتابیس')),
          ]),
        ),
      );

  // هر بار فراخوانی (مخصوصاً دکمه‌ی رفلش) یک اتصال تازه می‌سازد و دوباره می‌گیرد؛ قفل ندارد
  Future<void> _load({bool manual = false}) async {
    if (!_dbOk) return;
    final g = ++_gen;
    if (manual) {
      _seedTried = false;
      _seedErr = '';
      if (mounted) setState(() => _refreshing = true);
    }
    try {
      await _prepare();
      final r = await Future.wait([
        widget.client.call('GET', '/api/admin/stats'),
        widget.client.call('GET', '/api/admin/users'),
        widget.client.call('GET', '/api/admin/configs'),
      ]);
      if (!mounted || g < _applied) return;
      _applied = g;
      setState(() {
        _stats = (r[0] as Map).cast<String, dynamic>();
        _users = r[1] as List;
        _configs = r[2] as List;
        _err = '';
      });
      _afterLoad();
      if (manual) _liveTick(force: true);
    } catch (e) {
      if (mounted && g >= _applied) setState(() => _err = '$e'.replaceFirst('Exception: ', ''));
    } finally {
      if (manual && mounted) setState(() => _refreshing = false);
    }
  }

  // کانفیگ‌ها فقط از دیتابیس (Supabase) خوانده می‌شوند و از تب «کانفیگ‌ها» مدیریت می‌شوند
  Future<void> _prepare() async {}

  void _afterLoad() {
    final miss = _configs.where((c) => '${(c as Map)['country'] ?? ''}'.isEmpty && !_locTried.contains('${c['id']}')).toList();
    if (miss.isNotEmpty) {
      for (final c in miss) {
        _locTried.add('${(c as Map)['id']}');
      }
      widget.client.fillMissingLocations(miss).then((_) {
        if (mounted) _load();
      }).catchError((_) {});
    }
    _autoBackup();
  }

  // بکاپ خودکار روزانه داخل خود دیتابیس (۱۰ نسخه‌ی آخر نگه داشته می‌شود)
  Future<void> _autoBackup() async {
    if (_snapBusy) return;
    final now = DateTime.now().millisecondsSinceEpoch;
    if (now - (prefs.getInt('auto_snap_at') ?? 0) < 86400000) return;
    _snapBusy = true;
    try {
      await widget.client.createSnapshot('auto');
      await prefs.setInt('auto_snap_at', now);
    } catch (_) {
      await prefs.setInt('auto_snap_at', now - 86400000 + 3600000);
    } finally {
      _snapBusy = false;
    }
  }

  // کاربران فعال / غیرفعال / کل — هر ۳ ثانیه
  Future<void> _liveTick({bool force = false}) async {
    if (!_dbOk || _liveBusy || (_tab != 0 && !force)) return;
    _liveBusy = true;
    try {
      final m = await widget.client.liveCounts();
      if (mounted && (m['online'] != _live['online'] || m['total'] != _live['total'])) setState(() => _live = m);
    } catch (_) {
    } finally {
      _liveBusy = false;
    }
  }

  String _cfgName(Map x) {
    final n = '${x['name'] ?? ''}'.trim();
    final isIp = RegExp(r'^[\d.:\[\]a-fA-F]+$').hasMatch(n) && n.contains(RegExp(r'[.:]'));
    if (n.isNotEmpty && !isIp) return n;
    final c = '${x['country'] ?? ''}'.trim();
    if (c.isNotEmpty) return '${flagOf('${x['code'] ?? ''}')} $c';
    return 'در حال تشخیص لوکیشن...';
  }

  Widget _liveCard(String t, int v, IconData ic, Color col) => Expanded(
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 14),
          decoration: BoxDecoration(color: col.withOpacity(0.10), borderRadius: BorderRadius.circular(16), border: Border.all(color: col.withOpacity(0.55))),
          child: Column(children: [
            Icon(ic, color: col, size: 24),
            const SizedBox(height: 6),
            Text('$v', style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w800)),
            const SizedBox(height: 2),
            Text(t, style: const TextStyle(color: sub, fontSize: 12)),
          ]),
        ),
      );

  Widget _box(String t, String v, IconData ic, Color col) => Container(
        decoration: BoxDecoration(color: card, borderRadius: BorderRadius.circular(16), border: Border.all(color: border)),
        padding: const EdgeInsets.all(14),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Icon(ic, color: col, size: 26),
          const SizedBox(height: 6),
          FittedBox(child: Text(v, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800))),
          Text(t, style: const TextStyle(color: sub, fontSize: 12)),
        ]),
      );

  Widget _firefoxStats(dynamic raw) {
    final ff = raw is Map ? raw.cast<String, dynamic>() : <String, dynamic>{};
    final total = (ff['total'] as num?)?.toInt() ?? 0;
    final active = (ff['active'] as num?)?.toInt() ?? 0;
    final inactive = (ff['inactive'] as num?)?.toInt() ?? (total - active);
    final accounts = (ff['accounts'] as List?) ?? const [];
    const fox = Color(0xFFFF9500);
    return Container(
      margin: const EdgeInsets.only(top: 12),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: card, borderRadius: BorderRadius.circular(16), border: Border.all(color: border)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Row(children: [
          Icon(Icons.local_fire_department_rounded, color: fox, size: 20),
          SizedBox(width: 6),
          Text('اکانت‌های Firefox', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
        ]),
        const SizedBox(height: 10),
        if (ff['available'] != true)
          const Text('جدول آمار Firefox هنوز ساخته نشده؛ از تب «دیتابیس» دوباره «کپی SQL» را در Supabase اجرا کن.', style: TextStyle(color: sub, fontSize: 12, height: 1.6))
        else ...[
          Row(children: [
            _liveCard('کل اکانت‌ها', total, Icons.account_circle_rounded, fox),
            const SizedBox(width: 8),
            _liveCard('فعال', active, Icons.check_circle_rounded, Colors.greenAccent),
            const SizedBox(width: 8),
            _liveCard('غیرفعال', inactive, Icons.pause_circle_rounded, Colors.orangeAccent),
          ]),
          const SizedBox(height: 10),
          if (accounts.isEmpty) const Text('هنوز اکانتی گزارش نشده است.', style: TextStyle(color: sub)),
          for (final a in accounts.take(60)) _firefoxRow(a as Map),
          if (accounts.length > 60)
            Padding(padding: const EdgeInsets.only(top: 6), child: Text('و ${accounts.length - 60} اکانت دیگر…', style: const TextStyle(color: sub, fontSize: 12))),
          const Padding(
            padding: EdgeInsets.only(top: 8),
            child: Text('حجم‌ها تقریبی‌اند و با هر به‌روزرسانی اپ کاربر تازه می‌شوند؛ ایمیل‌ها ماسک‌شده‌اند.', style: TextStyle(color: sub, fontSize: 11)),
          ),
        ],
      ]),
    );
  }

  Widget _firefoxRow(Map a) {
    final unlimited = a['unlimited'] == true;
    final used = (a['used'] as num?) ?? 0;
    final limit = (a['limit'] as num?) ?? 0;
    final remaining = (a['remaining'] as num?) ?? 0;
    final active = a['active'] == true;
    final frac = (!unlimited && limit > 0) ? (used / limit).clamp(0.0, 1.0).toDouble() : null;
    final label = '${a['label']}'.isEmpty ? '—' : '${a['label']}';
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Icon(Icons.circle, size: 10, color: active ? Colors.greenAccent : Colors.orangeAccent),
          const SizedBox(width: 6),
          Expanded(child: Text(label, textDirection: TextDirection.ltr, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13))),
          Text(
            unlimited ? 'نامحدود' : (limit > 0 ? 'باقی‌مانده ${fmtBytes(remaining)} از ${fmtBytes(limit)}' : 'نامشخص'),
            style: const TextStyle(color: sub, fontSize: 11.5),
          ),
        ]),
        if (frac != null)
          Padding(
            padding: const EdgeInsets.only(top: 4),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(5),
              child: LinearProgressIndicator(value: frac, minHeight: 6, color: frac > 0.9 ? Colors.redAccent : accent2, backgroundColor: const Color(0xFF13234A)),
            ),
          ),
      ]),
    );
  }

  Widget _bars(String title, List<dynamic> items, {Color col = accent2, int limit = 6}) {
    final list = items.take(limit).toList();
    final maxV = list.isEmpty ? 1 : list.map((e) => e['value'] as num).reduce((a, b) => a > b ? a : b);
    return Container(
      margin: const EdgeInsets.only(top: 12),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: card, borderRadius: BorderRadius.circular(16), border: Border.all(color: border)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
        const SizedBox(height: 10),
        if (list.isEmpty) const Text('داده‌ای وجود ندارد', style: TextStyle(color: sub)),
        for (final e in list)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 4),
            child: Row(children: [
              SizedBox(width: 90, child: Text('${e['name']}', overflow: TextOverflow.ellipsis)),
              Expanded(
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(6),
                  child: LinearProgressIndicator(
                    value: maxV == 0 ? 0 : (e['value'] as num) / maxV,
                    minHeight: 12,
                    color: col,
                    backgroundColor: border.withOpacity(0.4),
                  ),
                ),
              ),
              SizedBox(width: 46, child: Text('${e['value']}', textAlign: TextAlign.end)),
            ]),
          ),
      ]),
    );
  }

  Widget _statsTab() {
    final s = _stats;
    if (s.isEmpty) {
      return Center(
        child: _err.isEmpty
            ? const CircularProgressIndicator()
            : Padding(
                padding: const EdgeInsets.all(24),
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  Text(_err, textAlign: TextAlign.center, style: const TextStyle(color: Colors.redAccent)),
                  const SizedBox(height: 12),
                  FilledButton(onPressed: () => setState(() => _tab = 3), child: const Text('بررسی دیتابیس')),
                ]),
              ),
      );
    }
    return RefreshIndicator(
      onRefresh: () => _load(manual: true),
      child: ListView(padding: const EdgeInsets.all(14), children: [
        Builder(builder: (context) {
          final on = _live['online'] ?? (s['online'] as num).toInt();
          final total = _live['total'] ?? (s['totalUsers'] as num).toInt();
          final off = _live['inactive'] ?? (total - on);
          return Column(children: [
            Row(children: [
              _liveCard('کاربران فعال', on, Icons.wifi_rounded, Colors.greenAccent),
              const SizedBox(width: 8),
              _liveCard('غیرفعال', off, Icons.wifi_off_rounded, Colors.orangeAccent),
              const SizedBox(width: 8),
              _liveCard('کل کاربران', total, Icons.people_rounded, accent2),
            ]),
            const Padding(
              padding: EdgeInsets.only(top: 6, bottom: 12),
              child: Text('فعال‌ها هر ۳ ثانیه و بقیه‌ی آمار هر ۱۰ ثانیه خودکار به‌روز می‌شود', style: TextStyle(color: sub, fontSize: 11)),
            ),
          ]);
        }),
        GridView.count(
          crossAxisCount: 2,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          mainAxisSpacing: 10,
          crossAxisSpacing: 10,
          childAspectRatio: 1.5,
          children: [
            _box('تعداد اتصالات', '${s['connections']}', Icons.link_rounded, Colors.amber),
            _box('فعال امروز', '${s['activeToday']}', Icons.today_rounded, Colors.pinkAccent),
            _box('کاربران جدید امروز', '${s['newToday'] ?? 0}', Icons.person_add_alt_1_rounded, Colors.orangeAccent),
            _box('حداقل یک‌بار وصل شده', '${s['everConnected'] ?? 0}', Icons.verified_user_rounded, Colors.cyanAccent),
            _box('بهترین لوکیشن', (s['bestLocation'] as String).isEmpty ? '—' : '${s['bestLocation']}', Icons.public_rounded, Colors.lightBlueAccent),
            _box('پرکاربردترین پروتکل', (s['bestProtocol'] as String).isEmpty ? '—' : '${s['bestProtocol']}'.toUpperCase(), Icons.shield_rounded, Colors.tealAccent),
            _box('کل آپلود', fmtBytes(s['up'] as num), Icons.arrow_upward_rounded, Colors.greenAccent),
            _box('کل دانلود', fmtBytes(s['down'] as num), Icons.arrow_downward_rounded, Colors.lightBlueAccent),
          ],
        ),
        _firefoxStats(s['firefox']),
        _bars('پروتکل‌ها', s['protocols'] as List),
        _bars('ترنسپورت‌ها', s['transports'] as List, col: Colors.tealAccent),
        _bars('لوکیشن‌ها', s['countries'] as List, col: Colors.amber),
        _bars('پلتفرم‌ها', s['platforms'] as List, col: Colors.pinkAccent),
        _bars('اتصالات ۷ روز اخیر', s['last7'] as List, col: accent, limit: 7),
        Padding(
          padding: const EdgeInsets.only(top: 12),
          child: Text('مجموع زمان اتصال: ${fmtDur(s['seconds'] as num)}', style: const TextStyle(color: sub)),
        ),
      ]),
    );
  }

  Widget _usersTab() {
    if (_users.isEmpty) return const Center(child: Text('کاربری وجود ندارد'));
    return RefreshIndicator(
      onRefresh: () => _load(manual: true),
      child: ListView.builder(
        padding: const EdgeInsets.all(14),
        itemCount: _users.length,
        itemBuilder: (c, i) {
          final u = _users[i] as Map;
          final online = u['online'] == true;
          return Container(
            margin: const EdgeInsets.only(bottom: 10),
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(color: card, borderRadius: BorderRadius.circular(16), border: Border.all(color: border)),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Icon(Icons.circle, size: 11, color: online ? Colors.greenAccent : Colors.grey),
                const SizedBox(width: 8),
                Expanded(child: Text(_shortId('${u['id']}'), textDirection: TextDirection.ltr, style: const TextStyle(fontWeight: FontWeight.w700))),
                Text('${u['platform']}', style: const TextStyle(color: accent2)),
              ]),
              const SizedBox(height: 8),
              Text('اتصالات: ${u['connections']}   |   پروتکل: ${u['lastProtocol']}   |   لوکیشن: ${u['lastCountry']}', style: const TextStyle(color: sub, fontSize: 12)),
              const SizedBox(height: 4),
              Text('آپلود: ${fmtBytes(u['up'] as num)}   |   دانلود: ${fmtBytes(u['down'] as num)}', style: const TextStyle(color: sub, fontSize: 12)),
              const SizedBox(height: 4),
              Text('آخرین بازدید: ${ago(u['lastSeen'] as int)}', style: const TextStyle(color: sub, fontSize: 12)),
            ]),
          );
        },
      ),
    );
  }

  Future<void> _addConfig() async {
    final text = TextEditingController();
    final name = TextEditingController();
    final quota = TextEditingController();
    final exp = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        backgroundColor: card,
        title: const Text('افزودن کانفیگ / ساب'),
        content: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            const Text(
              'یک یا چند لینک کانفیگ (vless / vmess / trojan / ss) یا لینک ساب (http/https) را بچسبان؛ کانفیگ‌ها خودکار استخراج می‌شوند.',
              style: TextStyle(color: sub, fontSize: 12, height: 1.6),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: text,
              maxLines: 6,
              minLines: 3,
              textDirection: TextDirection.ltr,
              decoration: const InputDecoration(labelText: 'کانفیگ‌ها یا لینک ساب', border: OutlineInputBorder()),
            ),
            TextButton.icon(
              onPressed: () async {
                final d = await Clipboard.getData('text/plain');
                if (d?.text != null) text.text = d!.text!;
              },
              icon: const Icon(Icons.paste_rounded, size: 18),
              label: const Text('چسباندن از کلیپ‌بورد'),
            ),
            TextField(controller: name, decoration: const InputDecoration(labelText: 'نام (اختیاری)')),
            TextField(controller: quota, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'حجم گیگ (اختیاری؛ از ساب خوانده می‌شود)')),
            TextField(controller: exp, decoration: const InputDecoration(labelText: 'تاریخ اعتبار (اختیاری)')),
          ]),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('لغو')),
          FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('استخراج و ثبت')),
        ],
      ),
    );
    if (ok != true || text.text.trim().isEmpty) return;
    try {
      final r = await widget.client.call('POST', '/api/admin/import', body: {
        'text': text.text.trim(),
        'name': name.text.trim(),
        if (quota.text.trim().isNotEmpty) 'quotaGb': num.tryParse(quota.text.trim()),
        'expires': exp.text.trim(),
      }) as Map;
      await _load();
      if (!mounted) return;
      final added = r['added'] ?? 0;
      final parts = <String>['$added کانفیگ اضافه شد'];
      if ((r['duplicates'] ?? 0) > 0) parts.add('${r['duplicates']} تکراری');
      if ((r['unsupported'] ?? 0) > 0) parts.add('${r['unsupported']} پروتکل پشتیبانی‌نشده');
      if ((r['invalid'] ?? 0) > 0) parts.add('${r['invalid']} نامعتبر');
      if ((r['found'] ?? 0) == 0 && (r['unsupported'] ?? 0) == 0) parts.add('کانفیگی در متن پیدا نشد');
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(parts.join(' • '))));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e'.replaceFirst('Exception: ', ''))));
    }
  }

  Future<void> _editConfig(Map x) async {
    final name = TextEditingController(text: '${x['name'] ?? ''}');
    final country = TextEditingController(text: '${x['country'] ?? ''}');
    final code = TextEditingController(text: '${x['code'] ?? ''}');
    final quota = TextEditingController(text: '${x['quotaGb'] ?? 0}');
    final exp = TextEditingController(text: '${x['expires'] ?? ''}');
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        backgroundColor: card,
        title: const Text('ویرایش کانفیگ'),
        content: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(controller: name, decoration: const InputDecoration(labelText: 'نام')),
            TextField(controller: country, decoration: const InputDecoration(labelText: 'لوکیشن (نام کشور)')),
            TextField(controller: code, textDirection: TextDirection.ltr, maxLength: 2, decoration: const InputDecoration(labelText: 'کد کشور (مثلا DE) برای پرچم')),
            TextField(controller: quota, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'حجم گیگ (۰ = نامحدود)')),
            TextField(controller: exp, decoration: const InputDecoration(labelText: 'تاریخ اعتبار')),
          ]),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('لغو')),
          FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('ذخیره')),
        ],
      ),
    );
    if (ok != true) return;
    try {
      await widget.client.call('PUT', '/api/admin/configs/${x['id']}', body: {
        'name': name.text.trim(),
        'country': country.text.trim(),
        'code': code.text.trim().toUpperCase(),
        'quotaGb': num.tryParse(quota.text.trim()) ?? 0,
        'expires': exp.text.trim(),
      });
      await _load();
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e'.replaceFirst('Exception: ', ''))));
    }
  }

  Widget _configsTab() {
    return Stack(children: [
      _configs.isEmpty
          ? Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  const Text('کانفیگی ثبت نشده'),
                  if (_seedErr.isNotEmpty) ...[
                    const SizedBox(height: 10),
                    Text(_seedErr, textAlign: TextAlign.center, style: const TextStyle(color: Colors.redAccent, fontSize: 12, height: 1.6)),
                  ],
                ]),
              ),
            )
          : ListView.builder(
              padding: const EdgeInsets.fromLTRB(14, 14, 14, 90),
              itemCount: _configs.length,
              itemBuilder: (c, i) {
                final x = _configs[i] as Map;
                final users = x['users'] ?? 0;
                final online = x['online'] ?? 0;
                final proto = '${x['protocol'] ?? '${x['link']}'.split('://').first}'.toUpperCase();
                final tr = '${x['transport'] ?? ''}';
                final sec = '${x['security'] ?? ''}';
                final kind = [proto, if (tr.isNotEmpty) tr, if (sec.isNotEmpty && sec != 'none') sec, if ('${x['source']}' == 'default') 'پیش‌فرض'].join(' · ');
                final loc = '${x['country'] ?? ''}'.isEmpty ? 'لوکیشن: نامشخص' : 'لوکیشن: ${flagOf('${x['code'] ?? ''}')} ${x['country']}';
                return Container(
                  margin: const EdgeInsets.only(bottom: 10),
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(color: card, borderRadius: BorderRadius.circular(16), border: Border.all(color: border)),
                  child: Row(children: [
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(_cfgName(x), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
                        const SizedBox(height: 4),
                        Text('${(x['quotaGb'] ?? 0) == 0 ? 'نامحدود' : '${x['quotaGb']} گیگ'}  |  ${'${x['expires']}'.isEmpty ? 'بدون انقضا' : x['expires']}  |  $users کاربر ($online آنلاین)', style: const TextStyle(color: sub, fontSize: 12)),
                        const SizedBox(height: 4),
                        Text('$kind   |   $loc', style: const TextStyle(color: accent2, fontSize: 12)),
                      ]),
                    ),
                    IconButton(icon: const Icon(Icons.edit_rounded, size: 20), onPressed: () => _editConfig(x)),
                    Switch(
                      value: x['enabled'] != false,
                      onChanged: (v) async {
                        await widget.client.call('PUT', '/api/admin/configs/${x['id']}', body: {'enabled': v});
                        _load();
                      },
                    ),
                    IconButton(
                      icon: const Icon(Icons.copy_rounded, size: 20),
                      onPressed: () => Clipboard.setData(ClipboardData(text: '${x['link']}')),
                    ),
                    IconButton(
                      icon: const Icon(Icons.delete_rounded, color: Colors.redAccent, size: 20),
                      onPressed: () async {
                        final id = '${x['id']}';
                        _applied = ++_gen;
                        setState(() => _configs = _configs.where((e) => '${(e as Map)['id']}' != id).toList());
                        try {
                          await widget.client.call('DELETE', '/api/admin/configs/$id');
                        } catch (e) {
                          if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('حذف ناموفق بود: $e')));
                        }
                        _load();
                      },
                    ),
                  ]),
                );
              },
            ),
      Positioned(
        bottom: 16,
        left: 16,
        child: FloatingActionButton.extended(onPressed: _addConfig, icon: const Icon(Icons.add), label: const Text('کانفیگ / ساب')),
      ),
    ]);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: bg,
        title: const Text('NEXORA Admin', style: TextStyle(fontWeight: FontWeight.w800)),
        actions: [
          IconButton(
            onPressed: () => _load(manual: true),
            icon: _refreshing ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.refresh_rounded),
          ),
          IconButton(onPressed: () => setState(() => _tab = 3), icon: const Icon(Icons.cloud_done_rounded)),
        ],
      ),
      body: IndexedStack(index: _tab, children: [_dbOk ? _statsTab() : _needDb(), _dbOk ? _usersTab() : _needDb(), _dbOk ? _configsTab() : _needDb(), const DbTab()]),
      bottomNavigationBar: NavigationBar(
        backgroundColor: card,
        selectedIndex: _tab,
        onDestinationSelected: (i) => setState(() => _tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.insights_rounded), label: 'آمار'),
          NavigationDestination(icon: Icon(Icons.people_rounded), label: 'کاربران'),
          NavigationDestination(icon: Icon(Icons.storage_rounded), label: 'کانفیگ‌ها'),
          NavigationDestination(icon: Icon(Icons.cloud_done_rounded), label: 'دیتابیس'),
        ],
      ),
    );
  }
}


class DbTab extends StatefulWidget {
  const DbTab({super.key});

  @override
  State<DbTab> createState() => _DbTabState();
}

class _DbTabState extends State<DbTab> {
  final _url = TextEditingController(text: prefs.getString('sb_url') ?? '');
  final _key = TextEditingController(text: prefs.getString('sb_key') ?? '');
  final _ghToken = TextEditingController(text: prefs.getString('gh_token') ?? '');
  bool _ghBusy = false;
  String _ghMsg = '';
  bool _bk = false;
  String _bkMsg = '';
  List<Map<String, dynamic>> _snaps = [];
  bool _hide = true;
  bool _busy = false;
  int _state = prefs.getInt('sb_state') ?? 0;
  String _reason = prefs.getString('sb_reason') ?? '';
  String _log = prefs.getString('sb_log') ?? '';

  String _norm(String v) {
    v = v.trim();
    final m = RegExp(r'supabase\.com/dashboard/project/([a-zA-Z0-9]+)').firstMatch(v);
    if (m != null) return 'https://${m.group(1)}.supabase.co';
    if (v.isEmpty) return v;
    if (!v.startsWith('http')) v = v.contains('.') ? 'https://$v' : 'https://$v.supabase.co';
    return v.replaceAll(RegExp(r'/(rest|auth)/v1.*$'), '').replaceAll(RegExp(r'/+$'), '');
  }

  String _t() {
    final n = DateTime.now();
    String two(int x) => x.toString().padLeft(2, '0');
    return '${two(n.hour)}:${two(n.minute)}:${two(n.second)}';
  }

  String _hint(int code, String body) {
    if (code == 401 || code == 403) {
      return 'کلید API اشتباه است یا دسترسی ندارد (کلید service_role / secret را از Project Settings ← API Keys کپی کن)';
    }
    if (code == 404 && (body.contains('PGRST205') || body.contains('42P01') || body.contains('relation'))) {
      return 'جدولی با این نام در دیتابیس وجود ندارد (نام جدول را بررسی کن یا اول بسازش)';
    }
    if (code == 404) return 'آدرس پروژه اشتباه است یا مسیر وجود ندارد';
    if (code == 400) return 'درخواست نامعتبر است (نام جدول یا ستون اشتباه)';
    if (code == 429) return 'تعداد درخواست زیاد است؛ کمی بعد دوباره تست کن';
    if (code == 540 || code == 522 || code == 523 || code == 521) return 'پروژه Supabase متوقف (Paused) شده؛ از داشبورد Restore کن';
    if (code >= 500) return 'خطای سمت سرور Supabase؛ وضعیت پروژه را در داشبورد ببین';
    return 'پاسخ غیرمنتظره از سرور';
  }

  String _errHint(Object e) {
    if (e is SocketException) return 'اتصال به اینترنت قطع است یا آدرس پروژه اشتباه است (DNS پیدا نشد)';
    if (e is TimeoutException) return 'زمان اتصال تمام شد؛ اینترنت یا فیلترینگ را بررسی کن';
    if (e is HandshakeException || e is TlsException) return 'خطای گواهی/TLS در اتصال امن';
    if (e is FormatException) return 'آدرس نامعتبر است';
    return 'خطای ناشناخته';
  }

  Future<String?> _step(StringBuffer b, String title, String url, String key) async {
    b.writeln('[${_t()}] $title');
    b.writeln('   GET $url');
    final c = HttpClient();
    c.connectionTimeout = const Duration(seconds: 10);
    try {
      final r = await c.getUrl(Uri.parse(url));
      r.headers.set('apikey', key);
      if (key.startsWith('eyJ')) r.headers.set('authorization', 'Bearer $key');
      r.headers.set('accept', 'application/json');
      final res = await r.close().timeout(const Duration(seconds: 15));
      final body = await res.transform(utf8.decoder).join();
      final short = body.length > 400 ? '${body.substring(0, 400)}...' : body;
      b.writeln('   status: ${res.statusCode}');
      if (short.isNotEmpty) b.writeln('   body: $short');
      if (res.statusCode >= 200 && res.statusCode < 300) {
        b.writeln('   نتیجه: موفق ✅');
        return null;
      }
      final h = _hint(res.statusCode, body);
      b.writeln('   نتیجه: ناموفق ❌');
      b.writeln('   دلیل: $h');
      return h;
    } catch (e) {
      final h = _errHint(e);
      b.writeln('   exception: ${e.runtimeType}: $e');
      b.writeln('   نتیجه: ناموفق ❌');
      b.writeln('   دلیل: $h');
      return h;
    } finally {
      c.close(force: true);
    }
  }

  Future<void> _saveAndTest() async {
    final url = _norm(_url.text);
    final key = _key.text.trim();
    _url.text = url;
    await prefs.setString('sb_url', url);
    await prefs.setString('sb_key', key);
    setState(() => _busy = true);
    final b = StringBuffer();
    b.writeln('[${_t()}] تنظیمات ذخیره شد');
    b.writeln('   آدرس: $url');
    b.writeln('   کلید: ${key.isEmpty ? '(خالی)' : '${key.substring(0, key.length < 8 ? key.length : 8)}••••  (${key.length} کاراکتر)'}');
    String? reason;
    final uri = Uri.tryParse(url);
    if (uri == null || uri.host.isEmpty || !url.startsWith('https://')) {
      reason = 'آدرس پروژه معتبر نیست (نمونه: https://xxxx.supabase.co)';
      b.writeln('[${_t()}] خطا: $reason');
    } else if (key.isEmpty) {
      reason = 'کلید API وارد نشده است';
      b.writeln('[${_t()}] خطا: $reason');
    } else {
      reason = await _step(b, 'مرحله ۱: بررسی پروژه و کلید (Auth)', '$url/auth/v1/health', key);
      for (final t in ['configs', 'users', 'events']) {
        if (reason != null) break;
        reason = await _step(b, 'مرحله: خواندن جدول $t', '$url/rest/v1/$t?select=*&limit=1', key);
        if (reason == null && t == 'users') {
          final r2 = await _step(b, 'مرحله: بررسی ستون‌های users', '$url/rest/v1/users?select=config_id,open_session,last_closed_session,last_protocol,last_country&limit=1', key);
          if (r2 != null) reason = 'ساختار جدول‌ها قدیمی است؛ «کپی SQL» را بزن و در Supabase › SQL Editor اجرا کن، بعد دوباره «ذخیره و تست اتصال»';
        }
        if (reason != null && reason.startsWith('جدولی')) {
          reason = 'جدول $t ساخته نشده؛ دکمه‌ی «کپی SQL» را بزن و در Supabase › SQL Editor اجرا کن';
        }
      }
      if (reason == null && !key.startsWith('eyJ') && !key.startsWith('sb_secret_')) {
        b.writeln('   هشدار: برای افزودن/ویرایش کانفیگ باید کلید service_role یا secret بگذاری (کلید anon فقط خواندن دارد)');
      }
    }
    b.writeln('[${_t()}] ${reason == null ? 'نتیجه نهایی: به دیتابیس وصل شدی ✅' : 'نتیجه نهایی: اتصال ناموفق ❌'}');
    await prefs.setInt('sb_state', reason == null ? 1 : 2);
    await prefs.setString('sb_reason', reason ?? '');
    await prefs.setString('sb_log', b.toString());
    dbEpoch.value++;
    dbState.value = reason == null ? 1 : 2;
    if (!mounted) return;
    setState(() {
      _busy = false;
      _state = reason == null ? 1 : 2;
      _reason = reason ?? '';
      _log = b.toString();
    });
  }

  Widget _field(TextEditingController c, String label, {bool secret = false, String? hint}) => Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: TextField(
          controller: c,
          obscureText: secret && _hide,
          textDirection: TextDirection.ltr,
          minLines: 1,
          maxLines: 1,
          decoration: InputDecoration(
            labelText: label,
            hintText: hint,
            border: const OutlineInputBorder(),
            suffixIcon: secret ? IconButton(icon: Icon(_hide ? Icons.visibility_rounded : Icons.visibility_off_rounded), onPressed: () => setState(() => _hide = !_hide)) : null,
          ),
        ),
      );

  Client _cl() {
    final u = (prefs.getString('sb_url') ?? '').trim();
    return Client(u.isEmpty ? kSbUrl : u, (prefs.getString('sb_key') ?? '').trim());
  }

  String _stamp() {
    final n = DateTime.now();
    String two(int x) => x.toString().padLeft(2, '0');
    return '${n.year}${two(n.month)}${two(n.day)}-${two(n.hour)}${two(n.minute)}';
  }

  void _toast(String m) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  Future<void> _guard(Future<void> Function() job) async {
    if (_bk) return;
    setState(() {
      _bk = true;
      _bkMsg = '';
    });
    try {
      await job();
    } catch (e) {
      if (mounted) setState(() => _bkMsg = '❌ ${'$e'.replaceFirst('Exception: ', '')}');
    } finally {
      if (mounted) setState(() => _bk = false);
    }
  }

  Future<void> _selfTest() async {
    setState(() => _busy = true);
    final r = await _cl().selfTest();
    final b = StringBuffer(_log)
      ..writeln('[${_t()}] تست ثبت کاربر و کانفیگ')
      ..write(r);
    await prefs.setString('sb_log', b.toString());
    if (!mounted) return;
    setState(() {
      _busy = false;
      _log = b.toString();
    });
  }

  Future<void> _backupFile() => _guard(() async {
        final d = await _cl().exportAll();
        final dir = await getTemporaryDirectory();
        final f = File('${dir.path}/parham-backup-${_stamp()}.json');
        await f.writeAsString(const JsonEncoder.withIndent(' ').convert(d));
        final c = d['counts'] as Map;
        if (mounted) setState(() => _bkMsg = '✅ بکاپ ساخته شد: ${c['configs']} کانفیگ، ${c['users']} کاربر، ${c['events']} رویداد');
        await Share.shareXFiles([XFile(f.path)], text: 'Parham VPN backup');
      });

  Future<void> _backupCopy() => _guard(() async {
        final d = await _cl().exportAll();
        await Clipboard.setData(ClipboardData(text: jsonEncode(d)));
        if (mounted) setState(() => _bkMsg = '✅ بکاپ در کلیپ‌بورد کپی شد (${(d['counts'] as Map)['configs']} کانفیگ، ${(d['counts'] as Map)['users']} کاربر)');
      });

  Future<void> _restoreClipboard() async {
    final clip = (await Clipboard.getData('text/plain'))?.text ?? '';
    Map<String, dynamic>? d;
    try {
      d = (jsonDecode(clip) as Map).cast<String, dynamic>();
    } catch (_) {}
    if (d == null || d['app'] != 'parham-vpn') {
      _toast('اول متن/فایل بکاپ را کپی کن (محتوای فایل JSON)');
      return;
    }
    final data = d;
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        backgroundColor: card,
        title: const Text('بازگردانی بکاپ'),
        content: Text('${(data['configs'] as List?)?.length ?? 0} کانفیگ و ${(data['users'] as List?)?.length ?? 0} کاربر در دیتابیس ادغام می‌شوند. چیزی پاک نمی‌شود؛ رکوردهای هم‌شناسه به‌روز می‌شوند.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('لغو')),
          FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('بازگردانی')),
        ],
      ),
    );
    if (ok != true) return;
    await _guard(() async {
      final r = await _cl().restoreAll(data);
      dbEpoch.value++;
      if (mounted) setState(() => _bkMsg = '✅ بازگردانی شد: ${r['configs']} کانفیگ، ${r['users']} کاربر، ${r['events']} رویداد');
    });
  }

  Future<void> _snapshot() => _guard(() async {
        final id = await _cl().createSnapshot('admin ${_stamp()}');
        _snaps = await _cl().listSnapshots();
        if (mounted) setState(() => _bkMsg = '✅ نسخه‌ی شماره‌ی $id داخل دیتابیس ذخیره شد');
      });

  Future<void> _loadSnaps() => _guard(() async {
        _snaps = await _cl().listSnapshots();
        if (mounted) setState(() => _bkMsg = _snaps.isEmpty ? 'هنوز نسخه‌ای داخل دیتابیس ساخته نشده' : '');
      });

  Future<void> _shareSnap(int id) => _guard(() async {
        final d = await _cl().snapshotData(id);
        final dir = await getTemporaryDirectory();
        final f = File('${dir.path}/parham-snapshot-$id.json');
        await f.writeAsString(const JsonEncoder.withIndent(' ').convert(d));
        await Share.shareXFiles([XFile(f.path)], text: 'Parham VPN snapshot $id');
      });

  Future<void> _ghSave() async {
    final t = _ghToken.text.trim();
    setState(() {
      _ghBusy = true;
      _ghMsg = '';
    });
    try {
      await _cl().setAppSetting('github_token', t);
      await prefs.setString('gh_token', t);
      if (mounted) setState(() => _ghMsg = t.isEmpty ? '✅ توکن حذف شد' : '✅ توکن ذخیره شد؛ اپ کاربران موقع باز شدن آن را می‌گیرد');
    } catch (e) {
      if (mounted) setState(() => _ghMsg = '❌ ${'$e'.replaceFirst('Exception: ', '')}');
    } finally {
      if (mounted) setState(() => _ghBusy = false);
    }
  }

  Future<void> _ghTest() async {
    final t = _ghToken.text.trim();
    setState(() {
      _ghBusy = true;
      _ghMsg = '';
    });
    final c = HttpClient()..connectionTimeout = const Duration(seconds: 12);
    try {
      final r = await c.getUrl(Uri.parse('https://api.github.com/rate_limit'));
      r.headers.set('User-Agent', 'NexoraAdmin');
      r.headers.set('Accept', 'application/vnd.github+json');
      if (t.isNotEmpty) r.headers.set('Authorization', 'Bearer $t');
      final res = await r.close().timeout(const Duration(seconds: 15));
      final body = await res.transform(utf8.decoder).join();
      if (res.statusCode == 401) {
        if (mounted) setState(() => _ghMsg = '❌ توکن نامعتبر است (401)');
      } else if (res.statusCode != 200) {
        if (mounted) setState(() => _ghMsg = '❌ پاسخ GitHub: ${res.statusCode}');
      } else {
        final core = ((jsonDecode(body) as Map)['resources'] as Map)['core'] as Map;
        if (mounted) setState(() => _ghMsg = '✅ توکن سالم است؛ سقف درخواست: ${core['limit']} در ساعت (باقی‌مانده ${core['remaining']})');
      }
    } catch (e) {
      if (mounted) setState(() => _ghMsg = '❌ اتصال به GitHub برقرار نشد');
    } finally {
      c.close(force: true);
      if (mounted) setState(() => _ghBusy = false);
    }
  }

  Widget _ghCard() {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: card, borderRadius: BorderRadius.circular(16), border: Border.all(color: border)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('توکن گیت‌هاب (به‌روزرسانی)', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
        const SizedBox(height: 4),
        const Text(
          'برای جلوگیری از Rate Limit گیت‌هاب و خواندن ریلیز ریپوی خصوصی، یک Personal Access Token فقط‌خواندنی (Contents: read) بگذار. '
          'توکن در دیتابیس ذخیره می‌شود و اپ کاربران برای چک کردن آپدیت از آن استفاده می‌کند. لازم است SQL جدید (کپی SQL) یک بار اجرا شده باشد.',
          style: TextStyle(color: sub, fontSize: 12, height: 1.6),
        ),
        const SizedBox(height: 12),
        _field(_ghToken, 'GitHub Token (ghp_… / github_pat_…)', secret: true),
        Row(children: [
          Expanded(
            child: FilledButton.icon(
              onPressed: _ghBusy ? null : _ghSave,
              icon: _ghBusy ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.save_rounded),
              label: const Text('ذخیره توکن'),
            ),
          ),
          const SizedBox(width: 8),
          Expanded(child: OutlinedButton.icon(onPressed: _ghBusy ? null : _ghTest, icon: const Icon(Icons.verified_rounded, size: 18), label: const Text('تست توکن'))),
        ]),
        if (_ghMsg.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 10), child: Text(_ghMsg, style: const TextStyle(fontSize: 12.5, height: 1.6))),
      ]),
    );
  }

  Widget _backupCard() {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: card, borderRadius: BorderRadius.circular(16), border: Border.all(color: border)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('بکاپ و بازگردانی', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
        const SizedBox(height: 4),
        const Text('کانفیگ‌ها، کاربران و آمار اتصال‌ها در یک فایل ذخیره می‌شوند. کلیدهای API داخل بکاپ نمی‌روند.', style: TextStyle(color: sub, fontSize: 12, height: 1.6)),
        const SizedBox(height: 12),
        SizedBox(
          width: double.infinity,
          child: FilledButton.icon(
            onPressed: _bk ? null : _backupFile,
            icon: _bk ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.download_rounded),
            label: const Text('دانلود بکاپ کامل (ذخیره / ارسال فایل)'),
          ),
        ),
        const SizedBox(height: 8),
        Row(children: [
          Expanded(child: OutlinedButton.icon(onPressed: _bk ? null : _backupCopy, icon: const Icon(Icons.copy_rounded, size: 18), label: const Text('کپی بکاپ'))),
          const SizedBox(width: 8),
          Expanded(child: OutlinedButton.icon(onPressed: _bk ? null : _restoreClipboard, icon: const Icon(Icons.restore_rounded, size: 18), label: const Text('بازگردانی'))),
        ]),
        const SizedBox(height: 8),
        Row(children: [
          Expanded(child: OutlinedButton.icon(onPressed: _bk ? null : _snapshot, icon: const Icon(Icons.save_alt_rounded, size: 18), label: const Text('نسخه‌ی امن در دیتابیس'))),
          const SizedBox(width: 8),
          Expanded(child: OutlinedButton.icon(onPressed: _bk ? null : _loadSnaps, icon: const Icon(Icons.list_alt_rounded, size: 18), label: const Text('لیست نسخه‌ها'))),
        ]),
        if (_bkMsg.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 10), child: Text(_bkMsg, style: const TextStyle(fontSize: 12.5, height: 1.6))),
        for (final sn in _snaps)
          ListTile(
            dense: true,
            contentPadding: EdgeInsets.zero,
            leading: const Icon(Icons.history_rounded, color: accent2),
            title: Text('نسخه ${sn['id']}  •  ${'${sn['created_at']}'.replaceFirst('T', ' ').split('.').first}', textDirection: TextDirection.ltr, style: const TextStyle(fontSize: 12.5)),
            trailing: IconButton(icon: const Icon(Icons.ios_share_rounded, size: 20), onPressed: _bk ? null : () => _shareSnap((sn['id'] as num).toInt())),
          ),
      ]),
    );
  }

  @override
  Widget build(BuildContext context) {
    final ok = _state == 1;
    final bad = _state == 2;
    final col = ok ? Colors.greenAccent : (bad ? Colors.redAccent : sub);
    return ListView(padding: const EdgeInsets.all(14), children: [
      Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(color: col.withOpacity(0.12), borderRadius: BorderRadius.circular(16), border: Border.all(color: col.withOpacity(0.6))),
        child: Row(children: [
          Icon(ok ? Icons.cloud_done_rounded : (bad ? Icons.cloud_off_rounded : Icons.cloud_queue_rounded), color: col, size: 30),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(ok ? 'به دیتابیس وصل شدی ✅' : (bad ? 'اتصال به دیتابیس ناموفق ❌' : 'هنوز تست نشده'), style: TextStyle(color: col, fontWeight: FontWeight.w800, fontSize: 15)),
              if (bad && _reason.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 4), child: Text('دلیل: $_reason', style: const TextStyle(color: sub, fontSize: 12, height: 1.6))),
            ]),
          ),
        ]),
      ),
      const SizedBox(height: 14),
      Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(color: card, borderRadius: BorderRadius.circular(16), border: Border.all(color: border)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('تنظیمات Supabase', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
          const SizedBox(height: 4),
          const Text('بار اول: ۱) «کپی SQL» و اجرا در Supabase  ۲) کلید service_role را بگذار  ۳) «ذخیره و تست». بعد از وصل شدن، آمار و کاربران و کانفیگ‌ها خودکار روشن می‌شوند.', style: TextStyle(color: sub, fontSize: 12, height: 1.6)),
          const SizedBox(height: 12),
          _field(_url, 'Project URL / لینک داشبورد', hint: 'https://xxxx.supabase.co'),
          _field(_key, 'API Key (کلید service_role / secret) — فقط داخل همین اپ ادمین', secret: true),
          SizedBox(
            width: double.infinity,
            child: OutlinedButton.icon(
              onPressed: () {
                Clipboard.setData(const ClipboardData(text: kSetupSql));
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('SQL کپی شد؛ در Supabase › SQL Editor بچسبان و Run بزن')));
              },
              icon: const Icon(Icons.copy_all_rounded),
              label: const Text('کپی SQL ساخت جدول‌ها (فقط بار اول)'),
            ),
          ),
          const SizedBox(height: 8),
          SizedBox(
            width: double.infinity,
            child: FilledButton.icon(
              onPressed: _busy ? null : _saveAndTest,
              icon: _busy ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.save_rounded),
              label: Text(_busy ? 'در حال تست...' : 'ذخیره و تست اتصال'),
            ),
          ),
          const SizedBox(height: 8),
          SizedBox(
            width: double.infinity,
            child: OutlinedButton.icon(
              onPressed: _busy ? null : _selfTest,
              icon: const Icon(Icons.bug_report_rounded),
              label: const Text('تست ثبت کاربر و کانفیگ'),
            ),
          ),
        ]),
      ),
      const SizedBox(height: 14),
      _ghCard(),
      const SizedBox(height: 14),
      _backupCard(),
      const SizedBox(height: 14),
      Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(color: card, borderRadius: BorderRadius.circular(16), border: Border.all(color: border)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            const Expanded(child: Text('لاگ اتصال', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 15))),
            TextButton.icon(
              onPressed: _log.isEmpty
                  ? null
                  : () {
                      Clipboard.setData(ClipboardData(text: _log));
                      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('لاگ کپی شد')));
                    },
              icon: const Icon(Icons.copy_rounded, size: 18),
              label: const Text('کپی لاگ'),
            ),
          ]),
          const SizedBox(height: 8),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(color: const Color(0xFF030816), borderRadius: BorderRadius.circular(12), border: Border.all(color: border.withOpacity(0.5))),
            child: SelectableText(
              _log.isEmpty ? 'هنوز تستی انجام نشده' : _log,
              textDirection: TextDirection.ltr,
              style: const TextStyle(fontFamily: 'monospace', fontSize: 11.5, height: 1.6, color: Color(0xFFCFE3FF)),
            ),
          ),
        ]),
      ),
    ]);
  }
}
