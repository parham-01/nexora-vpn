import 'dart:convert';
import 'package:flutter_v2ray/flutter_v2ray.dart';
import 'xray_config.dart';

typedef AndroidStatusCb = void Function(String state, int up, int down, int upSpeed, int downSpeed, String duration);

class AndroidVpn {
  FlutterV2ray? _v2;

  bool get supported => true;

  Future<void> init(AndroidStatusCb cb) async {
    _v2 = FlutterV2ray(onStatusChanged: (s) {
      cb('${s.state}', _i(s.upload), _i(s.download), _i(s.uploadSpeed), _i(s.downloadSpeed), '${s.duration}');
    });
    await _v2!.initializeV2Ray(
      notificationIconResourceType: 'mipmap',
      notificationIconResourceName: 'ic_launcher',
    );
  }

  int _i(dynamic v) => v is int ? v : int.tryParse('$v') ?? 0;

  String _config(String link, Map<String, dynamic> outbound, List<String> dns) {
    Map<String, dynamic>? base;
    try {
      final u = FlutterV2ray.parseFromURL(link);
      base = jsonDecode(u.getFullConfiguration()) as Map<String, dynamic>;
    } catch (_) {}
    base ??= mobileBaseConfig();
    final outs = List<dynamic>.from(base['outbounds'] as List? ?? []);
    final i = outs.indexWhere((o) => o is Map && o['tag'] == 'proxy');
    if (i >= 0) {
      outs[i] = outbound;
    } else {
      outs.insert(0, outbound);
    }
    base['outbounds'] = outs;
    if (dns.isNotEmpty) {
      final old = base['dns'] is Map ? Map<String, dynamic>.from(base['dns'] as Map) : <String, dynamic>{};
      old.addAll(dnsBlock(dns));
      base['dns'] = old;
    }
    return jsonEncode(base);
  }

  Future<bool> start(String link, String remark, Map<String, dynamic> outbound, {List<String> dns = const []}) async {
    final v2 = _v2;
    if (v2 == null) return false;
    if (!await v2.requestPermission()) return false;
    v2.startV2Ray(
      remark: remark,
      config: _config(link, outbound, dns),
      proxyOnly: false,
      bypassSubnets: <String>[],
      notificationDisconnectButtonName: 'قطع اتصال',
    );
    return true;
  }

  Future<void> stop() async {
    _v2?.stopV2Ray();
  }

  // پینگ واقعی (Relay): هسته‌ی v2ray کانفیگ را بالا می‌آورد و یک درخواست HTTP کامل از داخل آن می‌زند
  // (بدون نیاز به دسترسی VPN و بدون قطع اتصال فعلی). -1 یعنی شکست.
  Future<int> delay(String link, Map<String, dynamic> outbound) async {
    final v2 = _v2;
    if (v2 == null) return -1;
    try {
      final d = await (v2 as dynamic).getServerDelay(
        config: _config(link, outbound, const <String>[]),
        url: 'http://cp.cloudflare.com/generate_204',
      );
      final ms = d is int ? d : int.tryParse('$d') ?? -1;
      return ms >= 1 ? ms : -1;
    } catch (_) {
      return -1;
    }
  }
}
