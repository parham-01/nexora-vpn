import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'store.dart';

const String _sbBuildUrl = String.fromEnvironment('SB_URL', defaultValue: '');
const String _sbBuildKey = String.fromEnvironment('SB_KEY');
// اگر داخل اپ «کد اتصال» وارد شده باشد همان استفاده می‌شود، وگرنه مقدار زمان ساخت (SB_URL / SB_KEY)
String get sbUrl => Store.sbUrl.isNotEmpty ? Store.sbUrl : _sbBuildUrl;
String get sbKey => Store.sbKey.isNotEmpty ? Store.sbKey : _sbBuildKey.trim();

class Geo {
  final String ip, country, code;
  Geo(this.ip, this.country, this.code);

  String get flag {
    if (code.length != 2) return '🌐';
    final a = code.toUpperCase().codeUnits;
    return String.fromCharCodes([0x1F1E6 + a[0] - 65, 0x1F1E6 + a[1] - 65]);
  }
}

String flagOf(String code) {
  if (code.length != 2) return '🌐';
  final a = code.toUpperCase().codeUnits;
  return String.fromCharCodes([0x1F1E6 + a[0] - 65, 0x1F1E6 + a[1] - 65]);
}

// عنوان کانفیگ: نام یا لوکیشن (پرچم + کشور). آیپی/آدرس سرور هرگز نمایش داده نمی‌شود.
String cfgTitle(Map<String, dynamic> c) {
  final n = '${c['name'] ?? ''}'.trim();
  final isIp = RegExp(r'^[\d.:\[\]a-fA-F]+$').hasMatch(n) && n.contains(RegExp(r'[.:]'));
  if (n.isNotEmpty && !isIp) return n;
  final co = '${c['country'] ?? ''}'.trim();
  if (co.isNotEmpty) return '${flagOf('${c['code'] ?? ''}')} $co';
  final g = Store.geoCache[Api.hostOf('${c['link'] ?? ''}')];
  if (g is List && g.length == 2 && '${g[0]}'.isNotEmpty) return '${flagOf('${g[1]}')} ${g[0]}';
  return 'در حال تشخیص لوکیشن...';
}

class Api {
  static Future<dynamic> _request(String method, String url,
      {Map<String, dynamic>? body, String? proxy, int timeout = 15}) async {
    final c = HttpClient();
    c.connectionTimeout = const Duration(seconds: 10);
    if (proxy != null) c.findProxy = (_) => 'PROXY $proxy';
    try {
      final r = await c.openUrl(method, Uri.parse(url));
      r.headers.set('content-type', 'application/json');
      if (body != null) r.add(utf8.encode(jsonEncode(body)));
      final res = await r.close().timeout(Duration(seconds: timeout));
      final text = await res.transform(utf8.decoder).join();
      if (res.statusCode >= 400) throw HttpException('${res.statusCode}');
      return text.isEmpty ? null : jsonDecode(text);
    } finally {
      c.close(force: true);
    }
  }

  static Future<dynamic> _sb(String method, String path, {Object? body, int timeout = 15}) async {
    if (sbKey.isEmpty) throw const HttpException('no key');
    final c = HttpClient();
    c.connectionTimeout = const Duration(seconds: 10);
    try {
      final r = await c.openUrl(method, Uri.parse('$sbUrl/rest/v1/$path'));
      r.headers.set('apikey', sbKey);
      if (sbKey.startsWith('eyJ')) r.headers.set('authorization', 'Bearer $sbKey');
      r.headers.set('content-type', 'application/json');
      r.headers.set('accept', 'application/json');
      if (body != null) r.add(utf8.encode(jsonEncode(body)));
      final res = await r.close().timeout(Duration(seconds: timeout));
      final text = await res.transform(utf8.decoder).join();
      if (res.statusCode >= 400) throw HttpException('${res.statusCode} $text');
      return text.isEmpty ? null : jsonDecode(text);
    } finally {
      c.close(force: true);
    }
  }

  static Map<String, dynamic> _cfg(Map e) => {
        'id': '${e['id']}',
        'name': '${e['name'] ?? ''}',
        'quotaGb': e['quota_gb'] ?? 0,
        'expires': '${e['expires'] ?? ''}',
        'link': '${e['link'] ?? ''}',
        'protocol': '${e['protocol'] ?? ''}',
        'transport': '${e['transport'] ?? ''}',
        'country': '${e['country'] ?? ''}',
        'code': '${e['code'] ?? ''}',
      };

  static Future<Map<String, dynamic>?> fetchConfig({String? id}) async {
    if (!await sync()) return null;
    final l = Store.configs.value;
    if (l.isEmpty) return null;
    if (id != null && id.isNotEmpty) {
      for (final c in l) {
        if ('${c['id']}' == id) return c;
      }
    }
    return l.first;
  }

  static const String _cols = 'configs?select=id,name,quota_gb,expires,link,protocol,transport,country,code&enabled=eq.true&order=created_at.asc&limit=500';

  static String _sig(List<Map<String, dynamic>> l) => l.map((e) => '${e['id']}|${e['link']}|${e['name']}|${e['quotaGb']}|${e['expires']}').join(',');

  // بررسی بی‌صدا و سریع؛ حذف/تغییر کانفیگ از اپ ادمین بلافاصله روی همه‌ی کاربران اعمال می‌شود
  static bool _polling = false;
  static Future<void> pollConfigs() async {
    if (_polling) return;
    _polling = true;
    try {
      final r = await _sb('GET', _cols, timeout: 8);
      final list = (r as List).map((e) => _cfg(e as Map)).toList();
      if (_sig(list) == _sig(Store.configs.value)) return;
      await Store.setConfigs(list);
      if (list.isNotEmpty) unawaited(fillGeo());
    } catch (_) {
    } finally {
      _polling = false;
    }
  }

  static Future<bool> sync() async {
    unawaited(event({'type': 'hello'})); // کاربر حتی اگر خواندن کانفیگ‌ها شکست خورد ثبت شود
    try {
      final r = await _sb('GET',
          'configs?select=id,name,quota_gb,expires,link,protocol,transport,country,code&enabled=eq.true&order=created_at.asc&limit=500');
      final list = (r as List).map((e) => _cfg(e as Map)).toList();
      event({'type': 'hello'});
      if (list.isEmpty) {
        await Store.setConfigs([]);
        return true;
      }
      await Store.setConfigs(list);
      unawaited(fillGeo());
      return true;
    } catch (_) {
      return false;
    }
  }

  static Future<bool> reach({String? proxy}) async {
    for (final u in ['http://cp.cloudflare.com/generate_204', 'https://www.gstatic.com/generate_204']) {
      try {
        await _request('GET', u, proxy: proxy, timeout: 8);
        return true;
      } catch (_) {}
    }
    return false;
  }

  static Future<List<Map<String, dynamic>>> servers() async {
    await sync();
    return Store.configs.value;
  }

  static Future<void> event(Map<String, dynamic> d) async {
    try {
      await _sb('POST', 'rpc/report_event', body: {
        'p_device': Store.deviceId,
        'p_platform': Platform.operatingSystem,
        'p_type': '${d['type'] ?? 'hello'}',
        'p_session': '${d['session'] ?? ''}',
        'p_protocol': '${d['protocol'] ?? ''}',
        'p_transport': '${d['transport'] ?? ''}',
        'p_country': '${d['country'] ?? ''}',
        'p_config': '${d['configId'] ?? ''}',
        'p_up': (d['up'] as num?)?.toInt() ?? 0,
        'p_down': (d['down'] as num?)?.toInt() ?? 0,
        'p_seconds': (d['seconds'] as num?)?.toInt() ?? 0,
      }, timeout: 10);
    } catch (_) {}
  }

  // گزارش آمار اکانت‌های Firefox برای پنل ادمین (ایمیل ماسک‌شده؛ بی‌صدا و بدون خطا)
  static Future<void> reportFirefox(List<Map<String, dynamic>> accounts) async {
    try {
      await _sb('POST', 'rpc/report_firefox', body: {'p_device': Store.deviceId, 'p_accounts': accounts}, timeout: 10);
    } catch (_) {}
  }

  // تنظیمات عمومی برنامه که از پنل ادمین ذخیره می‌شود (مثلاً github_token برای خواندن ریلیزها)
  static Future<String> appSetting(String key) async {
    try {
      final r = await _sb('POST', 'rpc/get_app_setting', body: {'p_key': key}, timeout: 8);
      return r == null ? '' : '$r'.trim();
    } catch (_) {
      return '';
    }
  }

  static Future<int> pingLink(String link, {int timeoutSec = 4}) async {
    try {
      String host;
      int port;
      if (link.startsWith('vmess://')) {
        final raw = link.substring(8).split('#').first;
        final m = jsonDecode(utf8.decode(base64.decode(base64.normalize(raw)))) as Map;
        host = '${m['add']}';
        port = int.parse('${m['port']}');
      } else {
        final m = RegExp(r'@(\[[^\]]+\]|[^:/?#@]+):(\d+)').firstMatch(link);
        if (m == null) return -1;
        host = m.group(1)!.replaceAll(RegExp(r'[\[\]]'), '');
        port = int.parse(m.group(2)!);
      }
      final sw = Stopwatch()..start();
      final s = await Socket.connect(host, port, timeout: Duration(seconds: timeoutSec));
      sw.stop();
      s.destroy();
      return sw.elapsedMilliseconds;
    } catch (_) {
      return -1;
    }
  }

  // پینگ معتبر: بین ۱ تا ۳۰۰۰ میلی‌ثانیه. صفر، منفی یا بیشتر از ۳ ثانیه یعنی نامعتبر.
  static bool validPing(int ms) => ms >= 1 && ms <= 3000;

  // پینگ واقعی (دو اتصال TCP پشت سر هم به پورت سرور)؛ اگر هرکدام شکست بخورد یا عدد نامعتبر باشد -1
  static Future<int> realPing(String link, {int timeoutSec = 3}) async {
    final a = await pingLink(link, timeoutSec: timeoutSec);
    if (!validPing(a)) return -1;
    final b = await pingLink(link, timeoutSec: timeoutSec);
    if (!validPing(b)) return -1;
    return min(a, b);
  }

  // پینگ واقعی (Relay): یک درخواست HTTP کامل از داخل پراکسی/هسته‌ی کانفیگ؛ نه TCP ساده.
  // زمان کل درخواست تا رسیدن پاسخ generate_204 به میلی‌ثانیه، یا -1 اگر شکست خورد.
  // سریع: پینگ بالای ۳ ثانیه ویلید نیست، پس Timeout فقط ۴ ثانیه است؛ آدرس دوم (پشتیبان) فقط اگر اولی
  // ~۹۰۰ms جواب نداد موازی شروع می‌شود و هر کدام زودتر جواب داد برنده است (به‌جای ۸+۸ ثانیه انتظار پشت‌سرهم).
  static Future<int> delayVia(String proxy, {int timeoutSec = 4}) {
    const urls = ['http://cp.cloudflare.com/generate_204', 'http://www.gstatic.com/generate_204'];
    final done = Completer<int>();
    var failed = 0;
    void start(String u) {
      final sw = Stopwatch()..start();
      _request('GET', u, proxy: proxy, timeout: timeoutSec).then<void>((_) {
        if (!done.isCompleted) done.complete(max(1, sw.elapsedMilliseconds));
      }, onError: (Object _) {
        failed++;
        if (failed >= urls.length && !done.isCompleted) done.complete(-1);
      });
    }

    start(urls[0]);
    Timer(const Duration(milliseconds: 900), () {
      if (!done.isCompleted) start(urls[1]);
    });
    return done.future;
  }

  // تأخیر واقعی اینترنت از داخل تونل (میلی‌ثانیه) یا -1
  static Future<int> reachMs({String? proxy}) async {
    for (final u in ['http://cp.cloudflare.com/generate_204', 'https://www.gstatic.com/generate_204']) {
      final sw = Stopwatch()..start();
      try {
        await _request('GET', u, proxy: proxy, timeout: 8);
        sw.stop();
        return max(1, sw.elapsedMilliseconds);
      } catch (_) {}
    }
    return -1;
  }

  static String hostOf(String link) {
    try {
      if (link.startsWith('vmess://')) {
        final raw = link.substring(8).split('#').first;
        final m = jsonDecode(utf8.decode(base64.decode(base64.normalize(raw)))) as Map;
        return '${m['add']}';
      }
      final m = RegExp(r'@(\[[^\]]+\]|[^:/?#@]+):(\d+)').firstMatch(link);
      return m == null ? '' : m.group(1)!.replaceAll(RegExp(r'[\[\]]'), '');
    } catch (_) {
      return '';
    }
  }

  static bool _filling = false;
  static Future<void> fillGeo() async {
    if (_filling) return;
    _filling = true;
    try {
      final list = Store.configs.value;
      final need = [
        for (final c in list)
          if ('${c['country'] ?? ''}'.isEmpty) c
      ];
      if (need.isEmpty) return;
      final cache = Store.geoCache;
      final hosts = <String>{for (final c in need) hostOf('${c['link']}')}..remove('');
      final todo = hosts.where((h) => !cache.containsKey(h)).take(30).toList();
      for (var i = 0; i < todo.length; i += 5) {
        await Future.wait(todo.sublist(i, min(i + 5, todo.length)).map((h) async {
          try {
            final m = await _request('GET', 'https://ipwho.is/${Uri.encodeComponent(h)}', timeout: 8) as Map;
            if (m['success'] != false && '${m['country'] ?? ''}'.isNotEmpty) {
              cache[h] = ['${m['country']}', '${m['country_code'] ?? ''}'];
            }
          } catch (_) {}
        }));
      }
      await Store.setGeoCache(cache);
      var changed = false;
      final out = <Map<String, dynamic>>[];
      for (final c in list) {
        final x = Map<String, dynamic>.from(c);
        final g = cache[hostOf('${c['link']}')];
        if ('${x['country'] ?? ''}'.isEmpty && g is List && g.length == 2) {
          x['country'] = '${g[0]}';
          x['code'] = '${g[1]}';
          changed = true;
        }
        out.add(x);
      }
      if (changed) await Store.setConfigs(out);
    } catch (_) {
    } finally {
      _filling = false;
    }
  }

  static Future<Geo?> geo({String? proxy}) async {
    try {
      final r = await _request('GET', 'https://ipwho.is/', proxy: proxy);
      final m = (r as Map);
      return Geo('${m['ip']}', '${m['country']}', '${m['country_code']}');
    } catch (_) {
      return null;
    }
  }
}
