# Nexora VPN core notice

The Go core and the Android tunnel adapter in this directory are licensed under the GNU General Public License v3.0 (see `LICENSE` in this directory).
The HEV SOCKS5 tunnel source retains its own license files inside `android/hev-socks5-tunnel`.

A distributed build that includes this code must comply with GPL-3.0, including the source-code and license obligations.

## Platform support

- Android: Go mobile binding (`core.aar`) and HEV TUN adapter, built in CI.
- Windows: Go core and Windows TUN service, built in CI.
- iOS: no Packet Tunnel / Network Extension target is available, so the Firefox section shows an explicit unsupported notice.
